import requests

# Substitua pelo seu token do Discord
TOKEN = "MTI5NzU3MTUwMDMwMzU4NTM1NA.GHiOOf.R5yfNMNa4r-2aeKo3SCaSlXyJmNOtBYiL0SGmM"

def remove_hypesquad():
    """Remove o badge do HypeSquad da sua conta Discord"""
    
    url = "https://discord.com/api/v9/hypesquad/online"
    headers = {
        "Authorization": TOKEN
    }
    
    try:
        response = requests.delete(url, headers=headers)
        
        if response.status_code == 204:
            print("✓ Badge do HypeSquad removido com sucesso!")
        elif response.status_code == 401:
            print("✗ Erro: Token inválido ou expirado")
        elif response.status_code == 404:
            print("✗ Erro: Badge não encontrado (você pode não ter HypeSquad)")
        else:
            print(f"✗ Erro: {response.status_code}")
            print(f"Resposta: {response.text}")
    
    except Exception as e:
        print(f"✗ Erro na requisição: {e}")

if __name__ == "__main__":
    print("Removendo badge do HypeSquad...")
    remove_hypesquad()
